// import { gameMap, games } from '../../../../public/static/gamedatas'
//
//
// export default {
//     getHeaderMiddle: (cb) => cb(gameMap), // 获取头部中间的内容
//     getHeaderMiddleOrder: (cb) => cb(games) // 获取头部中间内容的顺序
//     // {
//     //     setTimeout(() => cb(games), 100)
//     // }
// }