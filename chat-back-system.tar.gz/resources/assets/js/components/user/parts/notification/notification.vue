<template>
    <div>notification</div>
</template>

<script>
    export default {
        name: "notification"
    }
</script>

<style scoped>

</style>