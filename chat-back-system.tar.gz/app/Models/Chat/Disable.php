<?php

namespace App\Models\Chat;

use Illuminate\Database\Eloquent\Model;

class Disable extends Model
{
    protected $fillable = [
        'name', 'type',
    ];
}
