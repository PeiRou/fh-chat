<template>
    <thead>
    <tr>
        <th colspan="3">{{ info.name }}</th>
    </tr>
    </thead>
</template>

<script>
    export default {
        props: {
            info: Object
        },
        name: "mspk10-sol-product_1_title",
    }
</script>

<style scoped>

</style>