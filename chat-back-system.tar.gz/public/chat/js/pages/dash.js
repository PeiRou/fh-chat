/**
 * Created by zoe on 2018/5/22.
 */
$(function () {
    $('#menu-dash').addClass('active');
});