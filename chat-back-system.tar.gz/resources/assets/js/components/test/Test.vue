<template>
    <div>
        <h1>Test</h1>
        <router-link to="/test/watch_vuex_computed">watch_vuex_computed</router-link>

        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: "test"
    }
</script>

<style scoped>

</style>