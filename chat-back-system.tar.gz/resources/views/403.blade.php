<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>403 - 无权访问</title>
    <style>
        *{margin:0;padding:0}html,code{font:15px/22px arial,sans-serif}html{background:#fff;color:#222;padding:15px}body{margin:7% auto 0;max-width:390px;min-height:180px;padding:30px 0 15px}* > body{background:url(/back/img/robot.png) 100% 5px no-repeat;padding-right:205px}p{margin:11px 0 22px;overflow:hidden}ins{color:#777;text-decoration:none}a img{border:0}@media screen and (max-width:772px){body{background:none;margin-top:0;max-width:none;padding-right:0}}#logo{display: inline-block;height: 54px;width: 156px;font-size: 27px;font-weight: bold;}.red{color:#ff6470}
    </style>
</head>
<body>
<span id="logo"><span class="red">AKJ</span>-ADMIN</span>
<p><b>403.</b> <ins>您无权访问此页面</ins>
<p>经系统鉴定您无权访问 <ins>如您获知有此权限仍旧无法访问，请联系技术支持！123</ins>
</body>
</html>