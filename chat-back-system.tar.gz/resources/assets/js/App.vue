<template>
    <!--<div id="app">-->
        <!--<h1>test完成</h1>-->
        <!--<img src="./assets/logo.png">-->
        <router-view/>
    <!--</div>-->
</template>

<script>
    export default {
        name: "App"
    }
</script>

<style scoped>

</style>