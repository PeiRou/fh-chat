<template>

</template>

<script>
    export default {
        name: "cont-main"
    }
</script>

<style scoped>

</style>