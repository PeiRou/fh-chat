<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubAccount extends Model
{
    protected $table = 'sub_account';
    protected $primaryKey = 'sa_id';
}
