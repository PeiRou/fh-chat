// import { playCates,plays } from "./../../../../public/static/gamedatas";
//
//
// export default {
//     getMspk10LmpName: (cb) => cb(playCates),  // 获取玩法种类
//     getMspk10LmpInput: (cb) => cb(plays)
// }